"""Shared application utilities."""
