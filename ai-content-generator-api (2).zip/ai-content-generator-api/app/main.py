from fastapi import FastAPI

from app.routes import generate, health
from app.utils.config import get_settings
from app.utils.exceptions import register_exception_handlers
from app.utils.logging_config import configure_logging
from app.utils.middleware import ResponseTimingMiddleware
from app.utils.rate_limiter import InMemoryRateLimitMiddleware

settings = get_settings()
configure_logging(settings.log_level)

app = FastAPI(
    title=settings.app_name,
    description="Production-ready FastAPI service for generating AI content with the Groq API.",
    version=settings.app_version,
    docs_url="/docs",
    redoc_url="/redoc",
)

# Cross-cutting middleware is registered close to application creation so all
# routes share the same operational behavior.
app.add_middleware(ResponseTimingMiddleware)
app.add_middleware(
    InMemoryRateLimitMiddleware,
    max_requests=settings.rate_limit_requests,
    window_seconds=settings.rate_limit_window_seconds,
    excluded_paths={"/health", "/docs", "/redoc", "/openapi.json"},
)

register_exception_handlers(app)

app.include_router(health.router)
app.include_router(generate.router)
