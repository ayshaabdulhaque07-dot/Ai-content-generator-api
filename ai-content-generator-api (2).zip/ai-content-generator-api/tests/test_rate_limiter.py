from fastapi import FastAPI
from fastapi.testclient import TestClient

from app.utils.rate_limiter import InMemoryRateLimiter


def test_rate_limiter_blocks_after_limit():
    limiter = InMemoryRateLimiter(max_requests=2, window_seconds=60)

    assert limiter.allow_request("127.0.0.1:/generate") is True
    assert limiter.allow_request("127.0.0.1:/generate") is True
    assert limiter.allow_request("127.0.0.1:/generate") is False


def test_rate_limit_middleware_returns_json_error():
    from app.utils.rate_limiter import InMemoryRateLimitMiddleware

    test_app = FastAPI()
    test_app.add_middleware(InMemoryRateLimitMiddleware, max_requests=1, window_seconds=60)

    @test_app.get("/limited")
    async def limited_endpoint():
        return {"ok": True}

    client = TestClient(test_app)

    assert client.get("/limited").status_code == 200
    response = client.get("/limited")

    assert response.status_code == 429
    assert response.json() == {
        "status": "error",
        "message": "Rate limit exceeded. Please try again later.",
    }
