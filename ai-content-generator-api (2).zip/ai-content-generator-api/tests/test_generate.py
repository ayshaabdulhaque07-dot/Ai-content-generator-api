def test_generate_returns_generated_text(client):
    response = client.post("/generate", json={"prompt": "Write a tagline for an AI content tool."})

    assert response.status_code == 200
    assert response.json() == {
        "generated_text": "Generated content for: Write a tagline for an AI content tool.",
        "status": "success",
    }
    assert "X-Process-Time-MS" in response.headers


def test_generate_rejects_empty_prompt(client):
    response = client.post("/generate", json={"prompt": "   "})

    assert response.status_code == 400
    assert response.json()["status"] == "error"
    assert "Prompt cannot be empty" in response.json()["message"]


def test_generate_handles_service_failure(failing_client):
    response = failing_client.post("/generate", json={"prompt": "Write a launch email."})

    assert response.status_code == 502
    assert response.json() == {
        "status": "error",
        "message": "Unable to generate content right now.",
    }
