import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.services.groq_service import get_groq_service


class FakeGroqService:
    async def generate_text(self, prompt: str) -> str:
        return f"Generated content for: {prompt}"


class FailingGroqService:
    async def generate_text(self, prompt: str) -> str:
        from app.services.groq_service import GroqServiceError

        raise GroqServiceError("Unable to generate content right now.")


@pytest.fixture
def client() -> TestClient:
    app.dependency_overrides[get_groq_service] = lambda: FakeGroqService()
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()


@pytest.fixture
def failing_client() -> TestClient:
    app.dependency_overrides[get_groq_service] = lambda: FailingGroqService()
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()
